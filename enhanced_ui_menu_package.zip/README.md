# Enhanced UI Menu

This is a Python package that provides a Tkinter-based UI menu with enhanced features and customization options. It includes sections with different UI elements, customization panels, and a settings system that persists user choices.

## Features

- Dynamic section swapping
- Background image support
- Logo customization
- Customizable themes, fonts, and colors
- Tooltip, status bar, and sound effect toggles
- Resizable frames and layouts
- Various UI widgets like sliders, dropdowns, and progress bars

## Installation

1. Clone the repository:

   ```bash
   git clone https://github.com/yourusername/enhanced_ui_menu.git
   cd enhanced_ui_menu
   ```

2. Install the package:

   ```bash
   pip install .
   ```

3. Run the application:

   ```bash
   enhanced-ui-menu
   ```

## Usage

- Customize the UI using the right-side panel.
- Navigate through sections using the buttons.
- Reset to defaults if needed.

## Contributing

Contributions are welcome! Please fork the repository and create a pull request.

## License

This project is licensed under the MIT License - see the LICENSE file for details.

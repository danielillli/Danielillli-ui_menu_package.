from enhanced_ui_menu.ui_elements import create_ui

def main():
    create_ui()

if __name__ == "__main__":
    main()
